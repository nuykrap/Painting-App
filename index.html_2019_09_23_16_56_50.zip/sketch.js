<html>
  <head>
    <script src="https://cdnjs.cloundflare.com/ajax/libs/p5.js/0.9.0/p5.min.js"></script>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/p5.js/0.9.0/addons/p5.dom.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/p5.js/0.9.0/addons/p5.sound.min.js"></script>
     <script src="sketch.js"></script>
    <style>
      html, body {margin:0; padding:0; overflow:hidden;}
     </style>
   </head>
  <body>
  </body>
</html>